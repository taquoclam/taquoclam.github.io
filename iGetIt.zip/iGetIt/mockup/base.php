<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="style.css" />
		<title>iGetIt</title>
	</head>
	<body>
		<header><h1>IGetIt</h1></header>
		<nav>
			<ul>
			<li> Sign Into A Class </li>
			<li> Profile </li>
			<li> Logout </li>
			</ul>
		</nav>
		<main>
			<h1></h1>
		</main>
		<footer>
		</footer>
	</body>
</html>

